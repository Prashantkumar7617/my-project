# Firebase Email Authentication Example App

In this application i have implemented firebase email authentication system. where user can create new account, login using the email and password.

## Features 
1. Create New account with email
2. Saved user Data with FireStore 
3. Forgot Password options
4. Verify User Email

#This android app source code is provided for the Video Tutorial Series on youtube channel (SmallAcademy) You can watch Full tutorial series here. 

https://www.youtube.com/embed/videoseries?list=PLlGT4GXi8_8dDK5Y3KCxuKAPpil9V49rN
