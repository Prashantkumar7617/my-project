# food-wastage-reduction
 a new internet-based application that provides a platform for donating old stuff and leftover food to all needy people/organizations
